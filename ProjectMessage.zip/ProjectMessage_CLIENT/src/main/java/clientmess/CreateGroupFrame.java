package clientmess;

import clientmess.payload.LoadFriendRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreateGroupFrame {

        JFrame CreateGroupFrame;
        JPanel createGroupPanel;
        JLabel labelTenTkFriend;
        JButton btnAddToGroup;
        JButton btnCreateGroup;
        JButton backToHome;
        final int LOAD_FRIEND_LIST_ACTION = 7;
        final int LOAD_FRIEND_LIST_ACTION_TO_CREATE_GROUP = 70;

     public CreateGroupFrame() {

        System.out.println("search Friends");
        CreateGroupFrame = new JFrame("Friend List");
        CreateGroupFrame.setSize(400, 600);
        CreateGroupFrame.setLocationRelativeTo(CreateGroupFrame);
        CreateGroupFrame.setResizable(true);
        CreateGroupFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //create button back to home
        backToHome = new JButton("Back to home");
        backToHome.setFocusPainted(false);
        backToHome.setForeground(Color.gray);
        backToHome.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CreateGroupFrame.setVisible(false);
                AppMessenger.displayLHomeFrame();
            }
        });
        btnCreateGroup = new JButton("Create Gr");
        //create panel
        createGroupPanel = new JPanel();
        BoxLayout boxlayoutChat = new BoxLayout(createGroupPanel, BoxLayout.Y_AXIS);
        createGroupPanel.setLayout(boxlayoutChat);
        createGroupPanel.setBorder(new EmptyBorder(50, 50, 470, 50));
        createGroupPanel.setBackground(Color.gray);

        //set Layout cho FrameChat
        CreateGroupFrame.setLayout(new GridLayout(1, 1));

        //add component to panel and frame
        createGroupPanel.add(backToHome);
        CreateGroupFrame.add(createGroupPanel);
        createGroupPanel.add(btnCreateGroup);
        CreateGroupFrame.setVisible(true);

    }
        public void hide() {
        CreateGroupFrame.setVisible(false);
    }

    }