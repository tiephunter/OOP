package clientmess.payload;

public class LoadUserRespond extends BasePayload {
    private int idFriend;
    private String nameFriend;

    public LoadUserRespond() {
    }

    public LoadUserRespond(int action, int idFriend, String nameFriend) {
        super(action);
        this.idFriend = idFriend;
        this.nameFriend = nameFriend;
    }

    public int getIdFriend() {
        return idFriend;
    }

    public void setIdFriend(int idFriend) {
        this.idFriend = idFriend;
    }

    public String getNameFriend() {
        return nameFriend;
    }

    public void setNameFriend(String nameFriend) {
        this.nameFriend = nameFriend;
    }
}
