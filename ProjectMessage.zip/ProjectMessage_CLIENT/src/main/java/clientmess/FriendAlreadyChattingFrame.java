package clientmess;

import javax.swing.*;

public class FriendAlreadyChattingFrame {
    JFrame frameHome ;
    JPanel Chat;


}
