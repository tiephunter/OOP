package server.payload;

public class LoadFriendRespond extends BasePayload {

}
