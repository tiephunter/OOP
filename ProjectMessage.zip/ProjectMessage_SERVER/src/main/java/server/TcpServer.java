/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import server.payload.*;

import java.math.BigInteger;
import java.net.Socket;
import java.net.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * @author cmtie
 */
public class TcpServer {


    private static ServerSocket myServer = null;

    private static Connection conn = null;
    private static String DB_URL = "jdbc:sqlserver://localhost:1433;"
            + "databaseName=Messenger;"
            + "integratedSecurity=true";
    private static String USER_NAME = "sa";
    private static String PASSWORD = "sa";
    public static HashMap<Integer, Socket> clientHashMap = null;

    public static ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public static void connectToDB(String dbURL, String userName, String password) {
        System.out.println("Start Connect to SQL");
        try {
            conn = DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
            System.out.println("connect successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //mo server Socket
    public static void openServer() {
        try {
            myServer = new ServerSocket(1234);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    //wait connect va chuyen connect
    public static void startServer() {
        try {
            while (true) {
                HandleConnection();
            }
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    //xu ly connection
    public static void HandleConnection() {
        try {
            Socket clientSocket = myServer.accept();
            System.out.println("client be accepted !");
            HandleClientThread clientthread = new HandleClientThread(conn, clientSocket);
            clientthread.start();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        connectToDB(DB_URL, USER_NAME, PASSWORD);
        clientHashMap = new HashMap();
        openServer();
        startServer();
    }
}

//handle thread de lay cac bien dung chung
class HandleClientThread extends Thread {

    Connection conn;
    Socket clientSocket;
//    HashMap<Integer, Socket> clientHashMap;

    DataInputStream in;
    DataOutputStream out;

    final static int SIGN_UP_ACTION = 1;
    final static int LOGIN_ACTION = 2;
    final static int LOGIN_SUCCESS = 3;
    final static int LOGIN_FALSE = 4;
    final static int LOAD_USER_lIST_ACTION = 5;
    final static int ADD_FRIEND_ACTION = 6;
    final static int ADD_FRIEND_SUCCESS = 8;
    final static int ADD_FRIEND_FAIL = 9;
    final static int LOAD_FRIEND_LIST_ACTION = 7;
    final static int CHAT_ACTION = 10;
    final static int CHAT_ACTION_SUCCESS = 11;
    final static int CHAT_ACTION_FAIL = 12;
    final static int SEND_MESSAGE_ACTION = 13;
    final static int RECEIVED_MESSAGE_ACTION = 14;
    final static int RECEIVED_MESSENGER_NOW = 15;
    final static int RECEIVED_MESSENGER_LATER = 16;
    final static int CREATE_GROUP_ACTION = 17;
    final static int LOAD_FRIEND_LIST_ACTION_TO_CREATE_GROUP = 70;
    public HandleClientThread(Connection conn, Socket clientSocket) {
        this.conn = conn;
        this.clientSocket = clientSocket;
//        this.clientHashMap = clientHashMap;
    }

    public static boolean testEmty(SignUpRequest signUpRequest) {
        if (signUpRequest.getTenTk().equals("") || signUpRequest.getTenMk().equals("") || signUpRequest.getHoten().equals("") || signUpRequest.getNgaysinh().equals("") || signUpRequest.getDiachi().equals("") || signUpRequest.getQuequan().equals("") || signUpRequest.getEmail().equals("")) {
            return true;
        }
        return false;
    }

    public static String encryptThisString(String input) {
        try {
            // getInstance() method is called with algorithm SHA-512
            MessageDigest md = MessageDigest.getInstance("SHA-512");

            // digest() method is called
            // to calculate message digest of the input string
            // returned as array of byte
            byte[] messageDigest = md.digest(input.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);

            // Add preceding 0s to make it 32 bit
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }

            // return the HashText
            return hashtext;
        }

        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    public void handleSignUp(SignUpRequest signUpRequest) throws Exception {

        String MatKhau = signUpRequest.getTenMk();
        System.out.println(MatKhau);
        String encryptPassword = encryptThisString(MatKhau);
        System.out.println("Mã hóa SHA 512" + encryptPassword);

        SignUpResponse signUpResponse = new SignUpResponse();
        // crate statement
        if (testEmty(signUpRequest) == true) {
            signUpResponse.setAction(SIGN_UP_ACTION);
            signUpResponse.setMessage("Ban chua dang nhap thong tin");
            out.writeUTF(TcpServer.mapper.writeValueAsString(signUpResponse));
            out.flush();
            return;

        } else {
            Statement stmt = conn.createStatement();
            // insert data to table
            stmt.execute("INSERT INTO Users(HoTen,NgaySinh,GioiTinh,DiaChi,QueQuan,Email,TenTaiKhoan,MatKhau)"
                    + " values(N'" + signUpRequest.getHoten() + "',N'" + signUpRequest.getNgaysinh() + "'," + signUpRequest.getGioitinh() + "" +
                    ",N'" + signUpRequest.getDiachi() + "',N'" + signUpRequest.getQuequan() + "',N'" + signUpRequest.getEmail() + "',N'" + signUpRequest.getTenTk() + "',N'" + encryptPassword + "')");
            signUpResponse.setAction(SIGN_UP_ACTION);
            signUpResponse.setMessage("Dang ki thanh cong");
            out.writeUTF(TcpServer.mapper.writeValueAsString(signUpResponse));
            out.flush();
        }
    }

    public void handleLogin(LogInRequest logInRequest) throws Exception {
//        String TenTaiKhoan = in.readUTF();
        String MatKhau = logInRequest.getPass();
        String encryptPass = encryptThisString(MatKhau);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("select *\n"
                + "from Users\n"
                + "where TenTaiKhoan = N'" + logInRequest.getAccount() + "' and MatKhau = N'" + encryptPass + "'");
        System.out.println("encryptPass" + encryptPass);
        System.out.println("Login by" + logInRequest.getAccount());
        if (rs.next()) {
            LogInRespond logInRespond = new LogInRespond(LOGIN_ACTION, LOGIN_SUCCESS, rs.getInt(1));
            String json = TcpServer.mapper.writeValueAsString(logInRespond);
            out.writeUTF(json);
            out.flush();
            TcpServer.clientHashMap.put(rs.getInt(1), clientSocket);
            System.out.println("HashMap" + TcpServer.clientHashMap);
        } else {
            LogInRespond logInRespond = new LogInRespond(LOGIN_ACTION, LOGIN_FALSE, 0);
            String json = TcpServer.mapper.writeValueAsString(logInRespond);
            out.writeUTF(json);
            out.flush();
        }
    }

    public void handleSearchUserList(LoadUserRequest loadUserRequest) throws Exception {

        int idUser = loadUserRequest.getIdUser();

        String tfSearch = loadUserRequest.getMessage();
        System.out.println("id User " + idUser + "Mess" + tfSearch);
        Statement stmtSearch = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

//        Statement stmtAmount = conn.createStatement();
        ResultSet rsSearch = stmtSearch.executeQuery("SELECT Users.IdUser, Users.TenTaiKhoan \n"
                + " from Users \n"
                + " where TenTaiKhoan like N'" + tfSearch + "%'  "
                + " except "
                + " select Users.IdUser, Users.TenTaiKhoan \n"
                + " from FriendShip, Users \n"
                + " where \n"
                + " FriendShip.UserId = " + idUser + " \n"
                + " and FriendShip.FriendId = Users.IdUser \n"
                + " except "
                + " select Users.IdUser, Users.TenTaiKhoan \n"
                + " from Users \n"
                + " where \n"
                + " Users.IdUser = " + idUser);


        rsSearch.last();
        System.out.println("amount of user " + rsSearch.getRow());
        BasePayload basePayload = new BasePayload(LOAD_USER_lIST_ACTION);
        String json = TcpServer.mapper.writeValueAsString(basePayload);
        out.writeUTF(json);
        out.writeInt(rsSearch.getRow());
        rsSearch.beforeFirst();
        while (rsSearch.next()) {
            System.out.println(rsSearch.getInt(1) + " " + rsSearch.getString(2));
            out.writeInt(rsSearch.getInt(1));
            out.writeUTF(rsSearch.getString(2));
        }
        out.flush();
//        rsSearch.last();
//        System.out.println("rs last" +rsSearch.last());
//        int amountRow = rsSearch.getRow();
//        System.out.println("amount of user "+amountRow);
////        out.writeInt(LOAD_USER_lIST_ACTION);
////        out.writeInt(rsSearch.getRow());
//        rsSearch.beforeFirst();
//        LoadUserRespond loadUserRespond = new LoadUserRespond();
//        System.out.println("test load user");
//        while (rsSearch.next()) {
//            System.out.println(rsSearch.getInt(1) + " " + rsSearch.getString(2) );
////            out.writeInt(rsSearch.getInt(1));
////            out.writeUTF(rsSearch.getString(2));
//            System.out.println("test load user 1");
//             loadUserRespond = new LoadUserRespond(LOAD_USER_lIST_ACTION,rsSearch.getInt(1),rsSearch.getString(2));
//             String json = TcpServer.mapper.writeValueAsString(loadUserRespond);
//             out.writeUTF(json);
//            System.out.println("test load user 2");
//        }
//        out.writeInt(amountRow);
//        out.flush();
    }

    public void handleAddFriend(AddFriendRequest addFriendRequest) throws Exception {
        int idUser = addFriendRequest.getIdUser();
        int idFriend = addFriendRequest.getIdFriend();
        String FriendName = addFriendRequest.getFriendName();

        LocalTime TimeStart = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
        LocalTime TimeFinish = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
        //insert to session
        PreparedStatement insertStmt = conn.prepareStatement("insert into "
                        + "Session(SessionName,AmountUsers, TimeStart, TimeFinish) "
                        + "values( N'"+ FriendName + "'," + 2 + ", '" + TimeStart + "', '" + TimeFinish + "')",
                Statement.RETURN_GENERATED_KEYS);
        insertStmt.execute();
        //insert to friend Ship
        LocalTime TimeCreated = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
        Statement stmtAddFriend = conn.createStatement();
        stmtAddFriend.execute("INSERT INTO FriendShip(UserId,FriendId,TimeCreated)"
                + "Values(" + idUser + "," + idFriend + ",'" + TimeCreated + "')");

        Statement stmtAddFriend1 = conn.createStatement();
        stmtAddFriend1.execute("INSERT INTO FriendShip(UserId,FriendId,TimeCreated)"
                + "Values(" + idFriend + "," + idUser + ",'" + TimeCreated + "')");
        //select from friendship
        Statement stmtCheckFriend = conn.createStatement();
        ResultSet rsCheckFriend = stmtCheckFriend.executeQuery("select * \n" +
                "from FriendShip " +
                "where UserId = " + idUser + " and FriendId = " + idFriend);
        if (rsCheckFriend.next()) {
            System.out.println("success add fr 1");
            AddFriendRespond addFriendRespond = new AddFriendRespond(ADD_FRIEND_ACTION,ADD_FRIEND_SUCCESS);
            String json = TcpServer.mapper.writeValueAsString(addFriendRespond);
            out.writeUTF(json);
            out.flush();
        } else {
            System.out.println("success add fr 2");
            AddFriendRespond addFriendRespond = new AddFriendRespond(ADD_FRIEND_ACTION,ADD_FRIEND_SUCCESS);
            String json = TcpServer.mapper.writeValueAsString(addFriendRespond);
            out.writeUTF(json);
            out.flush();
        }
    }

    public void handleLoadFriendList(LoadFriendRequest loadFriendRequest) throws Exception {
        int idUser = loadFriendRequest.getIdUser();
        Statement stmtSearchNameFriend = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

        ResultSet rsSearchNameFriend = stmtSearchNameFriend.executeQuery("select Users.IdUser, Users.TenTaiKhoan, Users.HoTen \n"
                + "from FriendShip, Users\n"
                + " where\n"
                + "FriendShip.UserId = " + idUser + "\n"
                + "and FriendShip.FriendId = Users.IdUser");

        rsSearchNameFriend.last();
        BasePayload basePayload = new BasePayload(LOAD_FRIEND_LIST_ACTION);
        String json = TcpServer.mapper.writeValueAsString(basePayload);
        out.writeUTF(json);
        out.writeInt(rsSearchNameFriend.getRow());
        System.out.println("Number of Friend " + rsSearchNameFriend.getRow());
        rsSearchNameFriend.beforeFirst();
        while (rsSearchNameFriend.next()) {

            out.writeInt(rsSearchNameFriend.getInt(1));
            out.writeUTF(rsSearchNameFriend.getString(2));
            out.writeUTF(rsSearchNameFriend.getString(3));
        }
        out.flush();
    }

    public void handleLoadFriendListToCreateGroup(LoadFriendRequest loadFriendRequest) throws Exception {
        int idUser = loadFriendRequest.getIdUser();
        Statement stmtSearchNameFriend = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

        ResultSet rsSearchNameFriend = stmtSearchNameFriend.executeQuery("select Users.IdUser, Users.TenTaiKhoan, Users.HoTen \n"
                + "from FriendShip, Users\n"
                + " where\n"
                + "FriendShip.UserId = " + idUser + "\n"
                + "and FriendShip.FriendId = Users.IdUser");

        rsSearchNameFriend.last();
        BasePayload basePayload = new BasePayload(LOAD_FRIEND_LIST_ACTION_TO_CREATE_GROUP);
        String json = TcpServer.mapper.writeValueAsString(basePayload);
        out.writeUTF(json);
        out.writeInt(rsSearchNameFriend.getRow());
        System.out.println("Number of Friend " + rsSearchNameFriend.getRow());
        rsSearchNameFriend.beforeFirst();
        while (rsSearchNameFriend.next()) {

            out.writeInt(rsSearchNameFriend.getInt(1));
            out.writeUTF(rsSearchNameFriend.getString(2));
            out.writeUTF(rsSearchNameFriend.getString(3));
        }
        out.flush();
    }

    public void handleCreateGroup(CreateGroupRequest createGroupRequest){
        try{
            int member = createGroupRequest.getMembersList().size();
            int amountMember = member + 1;
            ArrayList<Member> memberList = createGroupRequest.getMembersList();
            String sessionName ="";
            for (Member ms: memberList) {
                sessionName = sessionName + ms.getMemberName();
            }
            LocalTime TimeStart = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
            LocalTime TimeFinish = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
            //insert to session
            PreparedStatement insertStmt = conn.prepareStatement("insert into "
                            + "Session(SessionName,AmountUsers, TimeStart, TimeFinish) "
                            + "values( N'"+ sessionName + "'," + amountMember + ", '" + TimeStart + "', '" + TimeFinish + "')",
                    Statement.RETURN_GENERATED_KEYS);
            insertStmt.execute();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void handleChat(ChatRequest chatRequest) throws Exception {
        int idUser = chatRequest.getIdUser();
        int idFriend = chatRequest.getIdFriend();
        String tenTaiKhoanFriend = chatRequest.getTenTaiKhoanFriend();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("select *\n"
                + "from FriendShip\n"
                + "where UserId = " + idUser + " and FriendId = " + idFriend);
        if (rs.next()) {
            int sessionId = rs.getInt(4);
            if (sessionId == 0) {
                //insert into Seesion
//                LocalTime TimeStart = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
//                LocalTime TimeFinish = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
//
//                PreparedStatement insertStmt = conn.prepareStatement("insert into "
//                                + "Session(AmountUsers, TimeStart, TimeFinish) "
//                                + "values( " + 2 + ", '" + TimeStart + "', '" + TimeFinish + "')",
//                        Statement.RETURN_GENERATED_KEYS);
//                insertStmt.execute();
//
//                ResultSet insertRs = insertStmt.getGeneratedKeys();
//                if (insertRs.next()) {
//                    sessionId = insertRs.getInt(1);
//                    stmt.execute("update FriendShip set sessionId = " + sessionId + " where UserId = " + idUser + " and FriendId = " + idFriend);
//                    stmt.execute("update FriendShip set sessionId = " + sessionId + " where UserId = " + idFriend + " and FriendId = " + idUser);
//                }
                List<ChatMessage> messageList = new ArrayList<>();
                ChatRespond chatRespond = new ChatRespond(CHAT_ACTION, CHAT_ACTION_SUCCESS, idUser, idFriend, tenTaiKhoanFriend, sessionId, messageList);
                String json = TcpServer.mapper.writeValueAsString(chatRespond);
                out.writeUTF(json);
                out.flush();
            } else {

                Statement loadMessageStmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                ResultSet loadMessageRs = loadMessageStmt.executeQuery("select * from Message where IdSession = " + sessionId);
                loadMessageRs.last();
                loadMessageRs.beforeFirst();
                List<ChatMessage> messageList = new ArrayList<>();
                while (loadMessageRs.next()) {
//                    out.writeInt(loadMessageRs.getInt(1));
//                    out.writeUTF(loadMessageRs.getString(2));
//                    out.writeInt(loadMessageRs.getInt(5));
                    ChatMessage chatMessage = new ChatMessage(loadMessageRs.getInt(1), loadMessageRs.getString(2), loadMessageRs.getInt(5));
                    messageList.add(chatMessage);

                }
                ChatRespond chatRespond = new ChatRespond(CHAT_ACTION, CHAT_ACTION_SUCCESS, idUser, idFriend, tenTaiKhoanFriend, sessionId, messageList);
                String json = TcpServer.mapper.writeValueAsString(chatRespond);
                out.writeUTF(json);
                out.flush();
            }
        }

    }

    public void handleReceivedMsg(SendMessageRequest sendMessageRequest) throws Exception {
        int idSession = sendMessageRequest.getSessionID();
        String tfInputMsg = sendMessageRequest.getTfInputMessage();
        int idUser = sendMessageRequest.getIdUser();
        int idFriend = sendMessageRequest.getIdFriend();

        //check idFriend in map or not
        boolean testIdFriend = TcpServer.clientHashMap.containsKey(idFriend);
        //
        LocalTime TimeStart = LocalTime.now(ZoneId.of("Asia/Ho_Chi_Minh"));
        PreparedStatement stmt = conn.prepareStatement("insert into Message(TextMess,IdSession,Time,IdSender) "
                + "values(N'" + tfInputMsg + "'," + idSession + ",'" + TimeStart + "'," + idUser + ")", Statement.RETURN_GENERATED_KEYS);

        stmt.execute();
        ResultSet rs = stmt.getGeneratedKeys();
        System.out.println("detect success 1");
        while (rs.next()) {
            if (testIdFriend == true) {
                System.out.println("detect success 2");
                Socket friendSocket = TcpServer.clientHashMap.get(idFriend);
                DataOutputStream friendOut = new DataOutputStream(friendSocket.getOutputStream());
                SendMessageRespond sendMessageRespond = new SendMessageRespond(RECEIVED_MESSAGE_ACTION,RECEIVED_MESSENGER_NOW,rs.getInt(1),idSession,idUser,tfInputMsg);
                String json = TcpServer.mapper.writeValueAsString(sendMessageRespond);
                friendOut.writeUTF(json);
                friendOut.flush();
                System.out.println("gửi lúc onl");
            } else {
                System.out.println("offline");
            }
        }
    }

    public void run() {
        LoadFriendRequest loadFriendRequest;
        try {
            //takes input from client socket
            System.out.println("qqdsf");
            out = new DataOutputStream(clientSocket.getOutputStream());
            in = new DataInputStream(clientSocket.getInputStream());

            System.out.println("1");
            while (true) {
                //read messenge from client
//                System.out.println("2");
                Thread.sleep(1000);
                if (in.available() > 0) {
                    String json = in.readUTF();
                    BasePayload basePayload = TcpServer.mapper.readValue(json, BasePayload.class);
                    int action = basePayload.getAction();
                    switch (action) {
                        case SIGN_UP_ACTION:
                            System.out.println("go to singup action" + action);
                            SignUpRequest signUpRequest = TcpServer.mapper.readValue(json, SignUpRequest.class);
                            handleSignUp(signUpRequest);
                            break;
                        case LOGIN_ACTION:
//                            Thread.sleep(5000);
                            System.out.println("go to login action" + action);
                            LogInRequest logInRequest = TcpServer.mapper.readValue(json, LogInRequest.class);
                            handleLogin(logInRequest);
                            break;

                        case LOAD_USER_lIST_ACTION:
                            System.out.println("go to search user list ");
                            LoadUserRequest loadUserRequest = TcpServer.mapper.readValue(json, LoadUserRequest.class);
                            handleSearchUserList(loadUserRequest);
                            break;

                        case ADD_FRIEND_ACTION:
                            System.out.println("go to add friend ");
                            AddFriendRequest addFriendRequest = TcpServer.mapper.readValue(json,AddFriendRequest.class);
                            handleAddFriend(addFriendRequest);
                            break;

                        case LOAD_FRIEND_LIST_ACTION:
                            System.out.println("go to load Friends List ");
                             loadFriendRequest = TcpServer.mapper.readValue(json, LoadFriendRequest.class);
                            handleLoadFriendList(loadFriendRequest);
                            break;
                        case LOAD_FRIEND_LIST_ACTION_TO_CREATE_GROUP:
                            System.out.println("go to load Friends List to create group ");
                             loadFriendRequest = TcpServer.mapper.readValue(json, LoadFriendRequest.class);
                            handleLoadFriendListToCreateGroup(loadFriendRequest);
                            break;
                        case CREATE_GROUP_ACTION:
                            System.out.println("create group");
                            CreateGroupRequest createGroupRequest = TcpServer.mapper.readValue(json,CreateGroupRequest.class);
                            handleCreateGroup(createGroupRequest);
                            break;
                        case CHAT_ACTION:
                            System.out.println("go to chat ");
                            ChatRequest chatRequest = TcpServer.mapper.readValue(json, ChatRequest.class);
                            handleChat(chatRequest);
                            break;

                        case SEND_MESSAGE_ACTION:
                            System.out.println("go to recived Message Action");
                            SendMessageRequest sendMessageRequest = TcpServer.mapper.readValue(json,SendMessageRequest.class);
                            handleReceivedMsg(sendMessageRequest);
                            break;

                    }
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
